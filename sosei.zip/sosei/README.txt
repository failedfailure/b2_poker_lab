==================================
電子情報工学創成実験（情報通信）「対戦型ゲームの思考ルーチン」
サンプルプログラム

塩見 準
shiomi-jun@ist.osaka-u.ac.jp

Created on Apr 14, 2025
==================================


基本プログラム(ソースコード)
+ Server.java
+ Client.java 
+ CardClass.java
+ InfoClass.java
+ KnowledgeClass.java  <-　※ 実験ではこのファイルのみを変更します ※

過去の優秀プログラム(ビルド済み・ソースコードは提供しません)
+ KnowledgeClass0605.class
+ KnowledgeClass0703.class


【注意点】
過去の優秀プログラムを実行する場合は，
過去の優秀プログラムのファイル名を KnowledgeClass.class と変更した上で，
Client.class と同階層のフォルダに置く必要があります．
この時，作成中の KnowledgeClass.java を上書きしてしまわないように注意しましょう．

実行ごとに結果は　log***.txt　に出力されます．
出力結果が不用意に上書きされてしまわないように，
試合ごとにログファイル名を変更するなどの対応をしてください．

以上．
